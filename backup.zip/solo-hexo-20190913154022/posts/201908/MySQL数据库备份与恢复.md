title: MySQL数据库备份与恢复
date: '2019-08-16 17:20:57'
updated: '2019-08-16 17:20:57'
tags: [MySQL]
permalink: /articles/2019/08/16/1565947256975.html
---
## 备份：

**导出整个数据库**：

```
mysqldump -hhost -Pport -uusername -p database_name > filename.sql
```

**导出单个表：**

```
mysqldump -hhost -Pport -uusername -p database_name table_name > filename.sql
```

**导出并压缩**：

```
mysqldump -hhost -Pport -uusername -p database_name | gzip > filename.sql.gz
```

**导出所有库**：

```
mysqldump -all-databases > filename.sql
```

**只导表结构**：

```
mysqldump --opt -d database_name -hhost -Pport -uusername -p > filename.sql
```

**只导数据**：

```
mysqldump -t -hhost -Pport -uusername -p >filename.sql
```

**导出特定表德结构**：

```
mysqldump -hhost -Pport -uusername -p -B database_name --table_name > filename.sql
```

## 还原：

```
mysql -uroot -p < filename.sql

source /tmp/filename.sql
```
