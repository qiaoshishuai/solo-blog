title: MySQL的binlog日志学习
date: '2019-08-16 15:11:31'
updated: '2019-08-16 15:15:47'
tags: [MySQL]
permalink: /articles/2019/08/16/1565939491797.html
---
binlog 基本认识

MySQL的二进制日志可以说是MySQL最重要的日志了，它记录了所有的DDL和DML(除了数据查询语句)语句，以事件形式记录，还包含语句所执行的消耗的时间，MySQL的二进制日志是事务安全型的。

一般来说开启二进制日志大概会有1%的性能损耗(参见MySQL官方中文手册 5.1.24版)。二进制有两个最重要的使用场景:

其一：MySQL Replication在Master端开启binlog，Mster把它的二进制日志传递给slaves来达到master-slave数据一致的目的。

其二：自然就是数据恢复了，通过使用mysqlbinlog工具来使恢复数据。

二进制日志包括两类文件：二进制日志索引文件（文件名后缀为.index）用于记录所有的二进制文件，

二进制日志文件（文件名后缀为.00000*）记录数据库所有的DDL和DML(除了数据查询语句)语句事件。

一、开启binlog日志：

vi编辑打开mysql配置文件

```
# vi /usr/local/mysql/etc/my.cnf
```

在[mysqld] 区块

设置/添加 log-bin=mysql-bin 确认是打开状态(值 mysql-bin 是日志的基本名或前缀名)；

重启mysqld服务使配置生效

```
# pkill mysqld

# /usr/local/mysql/bin/mysqld_safe --user=mysql &
```

二、也可登录mysql服务器，通过mysql的变量配置表，查看二进制日志是否已开启

```
show variables like 'log_%';
```

三、常用binlog日志操作命令

1.查看所有binlog日志列表

```
mysql> show master logs;
```

2.查看master状态，即最后(最新)一个binlog日志的编号名称，及其最后一个操作事件pos结束点(Position)值

```
mysql> show master status;
```

3.刷新log日志，自此刻开始产生一个新编号的binlog日志文件

```
mysql> flush logs;
```

注：每当mysqld服务重启时，会自动执行此命令，刷新binlog日志；在mysqldump备份数据时加 -F 选项也会刷新binlog日志；

4.重置(清空)所有binlog日志

```
mysql> reset master;
```

四、查看某个binlog日志内容

1.# /usr/local/mysql/bin/mysqlbinlog /usr/local/mysql/data/mysql-bin.000013

2.show binlog events [IN 'log_name'] [FROM pos] [LIMIT [offset,] row_count];

A.查询第一个(最早)的binlog日志：

```
mysql> show binlog events\G;
```

B.指定查询 mysql-bin.000021 这个文件：

```
mysql> show binlog events in 'mysql-bin.000021'\G;

```
C.指定查询 mysql-bin.000021 这个文件，从pos点:8224开始查起：

```
mysql> show binlog events in 'mysql-bin.000021' from 8224\G;
```

D.指定查询 mysql-bin.000021 这个文件，从pos点:8224开始查起，查询10条

```
mysql> show binlog events in 'mysql-bin.000021' from 8224 limit 10\G;
```

E.指定查询 mysql-bin.000021 这个文件，从pos点:8224开始查起，偏移2行，查询10条

```
mysql> show binlog events in 'mysql-bin.000021' from 8224 limit 2,10\G;
```
