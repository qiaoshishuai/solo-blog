title: Zabbix简介
date: '2019-08-16 15:06:35'
updated: '2019-08-16 15:06:43'
tags: [Zabbix]
permalink: /articles/2019/08/16/1565939195829.html
---
zabbix是一个基于WEB界面的提供分布式系统监视以及网络监视功能的企业级的开源解决方案。

zabbix由zabbix server与可选组件zabbix agent两部门组成。

zabbix server可以通过SNMP，zabbix agent，ping，端口监视等方法提供对远程服务器/网络状态的监

视。

zabbix agent需要安装在被监视的目标服务器上，它主要完成对硬件信息或与操作系统有关的内存CPU

等信息的收集。

Ubuntu上Zabbix Server 端 Web环境搭建

```
wget http://repo.zabbix.com/zabbix/3.4/ubuntu/pool/main/z/zabbix-release/zabbixrelease_3.4-1+xenial_all.deb 
dpkg -i zabbix-release_3.4-1+xenial_all.deb 
apt-get update
```

安装Zabbix部署包

使用mysql数据库安装Zabbix server、WEB前端的示例。

apt-get install zabbix-server-mysql zabbix-frontend-php

安装初始化数据库MySQL

```
shell> mysql -uroot -p<your_password> 
mysql> create database zabbix character set utf8 collate utf8_bin; 
mysql> grant all privileges on zabbix.* to zabbix@localhost identified by '<your_password>'; 
mysql> quit;
```

If you use Zabbix packages continue with instructions for Debian/Ubuntu or RHEL/CentOS to import the data into the database.

```
shell> cd database/mysql 
shell> mysql -uzabbix -p<password> zabbix < schema.sql 
stop here if you are creating database for Zabbix proxy 
shell> mysql -uzabbix -p<password> zabbix < images.sql 
shell> mysql -uzabbix -p<password> zabbix < data.sql
```

然后导入初始架构（Schema）和数据

```
cd /usr/share/doc/zabbix-server-mysql 
zcat create.sql.gz | mysql -uroot zabbix
```

* 业务机Zabbix Agent在业务机上的部署

安装zabbix源

```
wget http://repo.zabbix.com/zabbix/3.2/ubuntu/pool/main/z/zabbix-release/zabbix-release_3.2-1+xenial_all.deb 
dpkg -i zabbix-release_3.2-1+xenial_all.deb 
apt install -y zabbix-agent
```

修改/etc/zabbix/zabbix_agentd.conf文件

hostname server serverActive (zabbix-server)

开启zabbix-agent服务：service start zabbix-agent

zabbix 项目自定义监控

创建脚本目录 我的是 /usr/local/zabbix/script

1.监控docker容器状态

1>zabbix客户端操作

脚本目录下创建获取容器名称的py脚本

脚本目录下创建获取容器状态的py脚本

/etc/zabbix/zabbix_agentd.d目录下创建.conf文件（通过/etc/zabbix/zabbix_agentd.conf中Include=/etc/zabbix/zabbix_agentd.d/*.conf获取到配置文件）

.conf文件中添加：UserParameter = parameter , scriptpath(脚本路径)

2>zabbix_web端操作

主机添加自动发现，键值即parameter

为添加的自动发现添加监控项原型，键值即parameter

为添加的监控项原型添加触发器，定义表达式

为添加的监控项原型添加图像原型

2.监控mysql的连接数

1>zabbix客户端操作

脚本目录下创建获取mysql连接数的脚本

/etc/zabbix/zabbix_agentd.d目录下创建userparameter_docker.conf文件

.conf文件中添加：UserParameter = parameter , scriptpath(脚本路径)

2>zabbix_web端操作

主机添加监控项，键值即parameter

为添加的监控项添加触发器，定义表达式

为添加的监控项原型添加图像原型

3.监控redis的连接数

同mysql
