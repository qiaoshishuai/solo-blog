title: 使用阿里云免费SSL证书实现全站HTTPS化
date: '2019-08-16 15:01:38'
updated: '2019-08-16 15:01:38'
tags: [待分类]
permalink: /articles/2019/08/16/1565938898834.html
---
苹果和小程序开发都开始要求使用https服务，而且运营商广告注入也越来越疯狂。所以，实现网站https很用必要。

实现https就需要一个SSL证书。证书大部分都很贵，不过也有一些免费的证书服务供个人开发者使用，这是一个大好消息。比如腾讯云，七牛云，阿里云。

我们今天就拿阿里云来实践一下，因为我的服务器也在这里。

## 购买免费SSL证书

首先第一步就是获取一个证书。来到阿里云购买证书页面。传送门：[阿里云免费SSL地址](https://common-buy.aliyun.com/?spm=5176.2020520163.cas.1.2arDtO&commodityCode=cas#/buy)  

![null](//upload-images.jianshu.io/upload_images/4097351-469f831edaa58924.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1000/format/webp)

ssss.png

  
之后，去阿里云控制台，选择菜安全（云盾）->证书服务，可以找到刚刚的购买好的订单。

### 补全信息

补全信息就是填写一些你的域名信息和你的个人信息，顺带验证下域名是你的。

第一步是填写域名。这里不能写通配符域名，需要写普通域名，就是类似于[www.baidu.com](http://www.baidu.com)或者[images.baidu.com](http://images.baidu.com)这种。

所以，当你需要多个二级域名的时候，你需要购买多个免费的SSL证书。

## 下载证书

## 安装证书

文件说明：

##### 1. 证书文件214927684720376.pem，包含两段内容，请不要删除任何一段内容。

##### 2. 如果是证书系统创建的CSR，还包含：证书私钥文件214927684720376.key。

( 1 ) 在Nginx的安装目录下创建cert目录，并且将下载的全部文件拷贝到cert目录中。如果申请证书时是自己创建的CSR文件，请将对应的私钥文件放到cert目录下并且命名为214927684720376.key；  
( 2 ) 打开 Nginx 安装目录下 conf 目录中的 nginx.conf 文件，找到：

```
# HTTPS server
# #server {
# listen 443;
# server_name localhost;
# ssl on;
# ssl_certificate cert.pem;
# ssl_certificate_key cert.key;
# ssl_session_timeout 5m;
# ssl_protocols SSLv2 SSLv3 TLSv1;
# ssl_ciphers ALL:!ADH:!EXPORT56:RC4+RSA:+HIGH:+MEDIUM:+LOW:+SSLv2:+EXP;
# ssl_prefer_server_ciphers on;
# location / {
#
#
#}
#}

```

##### ( 3 ) 将其修改为 (以下属性中ssl开头的属性与证书配置有直接关系，其它属性请结合自己的实际情况复制或调整) :

```
server {
    listen 443;
    server_name localhost;
    ssl on;
    root html;
    index index.html index.htm;
    ssl_certificate   cert/214927684720376.pem;
    ssl_certificate_key  cert/214927684720376.key;
    ssl_session_timeout 5m;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE:ECDH:AES:HIGH:!NULL:!aNULL:!MD5:!ADH:!RC4;
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
    ssl_prefer_server_ciphers on;
    location / {
        root html;
        index index.html index.htm;
    }
}

```

保存退出。

##### ( 4 )重启 Nginx。

##### ( 5 ) 通过 https 方式访问您的站点，测试站点证书的安装配置。如遇到证书不信任问题，请[查看帮助视频](https://help.aliyun.com/video_detail/54216.html)。

