title: Docker版本Jenkins的使用
date: '2019-08-15 10:52:13'
updated: '2019-08-30 14:06:21'
tags: [Jenkins]
permalink: /articles/2019/08/15/1565837533876.html
---
1. 什么是Jenkins？

Jenkins是当前非常流行的一款持续集成工具，可以将更新后的代码自动部署到服务器上运行；

2. 安装jenkins：

1.安装docker

2.docker镜像官网地址：https://jenkins.io/download

3.下载官方镜像到服务器

`docker pull jenkins/jenkins`

4.启动jenkins镜像（jenkins默认端口号为8080，另外还需要暴露一个tcp的端口号为50000）

`docker run -d -p 80:8080 -p 50000:50000 -v jenkins:/var/jenkins_home -v /etc/localtime:/etc/localtime --name jenkins docker.io/jenkins/jenkins`

参数的意义：

-d 后台运行镜像

-p 80:8080 将镜像的8080端口映射到服务器的80端口

-p 50000:50000 将镜像的50000端口映射到服务器的50000端口

-v jenkins:/var/jenkins_home /var/jenkins_home目录为jenkins工作目录，我们将硬盘上的一个目录挂载到这个位置，方便后续更新镜像后继续使用原来的工作目录。

-v /etc/localtime:/etc/localtime 让容器使用和服务器同样的时间设置。

--name jenkins 给容器起一个别名

这个时候，docker版本的Jenkins就已经安装完成了

3. 配置Jenkins:

1.浏览器输入http:ip:port 访问Jenkins，进入Jenkins初始登陆界面，根据提示复制密钥：

首先进入创建好的容器

`docker exec -it myjenkins bash`

根据提示目录复制密钥

`cd /var/jenkins_home/secrets cat initialAdminPassword`

2.点击左边的Install suggested plugins，安装推荐插件

3.安装完成后，建立管理员账户1. 什么是Jenkins？

Jenkins是当前非常流行的一款持续集成工具，可以将更新后的代码自动部署到服务器上运行；

2. 安装jenkins：

1.安装docker

2.docker镜像官网地址：https://jenkins.io/download

3.下载官方镜像到服务器

`docker pull jenkins/jenkins`

4.启动jenkins镜像（jenkins默认端口号为8080，另外还需要暴露一个tcp的端口号为50000）

`docker run -d -p 80:8080 -p 50000:50000 -v jenkins:/var/jenkins_home -v /etc/localtime:/etc/localtime --name jenkins docker.io/jenkins/jenkins`

参数的意义：

-d 后台运行镜像

-p 80:8080 将镜像的8080端口映射到服务器的80端口

-p 50000:50000 将镜像的50000端口映射到服务器的50000端口

-v jenkins:/var/jenkins_home /var/jenkins_home目录为jenkins工作目录，我们将硬盘上的一个目录挂载到这个位置，方便后续更新镜像后继续使用原来的工作目录。

-v /etc/localtime:/etc/localtime 让容器使用和服务器同样的时间设置。

--name jenkins 给容器起一个别名

这个时候，docker版本的Jenkins就已经安装完成了

3. 配置Jenkins:

1.浏览器输入http:ip:port 访问Jenkins，进入Jenkins初始登陆界面，根据提示复制密钥：

首先进入创建好的容器
`
docker exec -it myjenkins bash`

根据提示目录复制密钥

`cd /var/jenkins_home/secrets cat initialAdminPassword`

2.点击左边的Install suggested plugins，安装推荐插件

3.安装完成后，建立管理员账户
