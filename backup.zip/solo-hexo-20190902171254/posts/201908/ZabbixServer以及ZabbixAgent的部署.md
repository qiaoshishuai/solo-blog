title: Zabbix Server以及Zabbix Agent的部署
date: '2019-08-27 15:41:24'
updated: '2019-08-27 15:41:24'
tags: [Zabbix]
permalink: /articles/2019/08/27/1566891684446.html
---
![](https://img.hacpai.com/bing/20180528.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

1. 部署Zabbix服务端

> 服务端我们选择在docker中部署Zabbix appliance ，该镜像内置了Mysql、Zabbix Server、Nginx
```
docker run --name zabbix-appliance -t \
    -p 10051:10051 \
    -p 80:80 \
    -d zabbix/zabbix-appliance:latest
```
> 服务端安装完成，就可以访问了，默认的登陆账号密码为admin/zabbix

2.部署Zabbix agent

>Zabbix agent 部署在被监控的机器上 

```
apt install zabbix-agent
```

> 修改Zabbix agent配置文件

```
vim /etc/zabbix/zabbix_agentd.conf
```

> 开启Zabbix agent服务

```
service zabbix-agent start
```
