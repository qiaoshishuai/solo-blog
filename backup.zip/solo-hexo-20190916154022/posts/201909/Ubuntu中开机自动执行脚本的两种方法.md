title: Ubuntu 中开机自动执行脚本的两种方法
date: '2019-09-04 14:56:30'
updated: '2019-09-04 14:56:30'
tags: [Linux]
permalink: /articles/2019/09/04/1567580190455.html
---
### 方法1:

`rc.local`脚本是一个ubuntu开机后会自动执行的脚本，我们可以在该脚本内添加命令行指令。

### 方法2:

1. 建立自己的脚本, 例如:
    
    ```bash
    #!/bin/bash
    cd /home/ubuntu/undertow-server/
    sudo mvn exec:java
    
    ```
    
    保存为`run_server.sh`
    
2. 修改脚本执行权限:
    
    ```css
    chmod +x run_server.sh
    
    ```
    
3. 将脚本放入`/etc/init.d`路径下
    
    ```undefined
    cp run_server.sh /etc/init.d/
    
    ```
    
4. 将脚本添加到启动脚本:
    
    ```bash
    cd /etc/init.d/
    update-rc.d run_server defaults 90
    
    ```
    
    在这里`90`表明一个优先级，越高表示执行的越晚.
    
5. 移除脚本也很简单:
    
    ```css
    update-rc.d -f run_server.sh remove
    ```
