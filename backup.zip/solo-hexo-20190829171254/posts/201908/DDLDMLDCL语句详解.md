title: DDL 、 DML 、 DCL 语句详解
date: '2019-08-15 16:48:55'
updated: '2019-08-15 16:51:42'
tags: [MySQL]
permalink: /articles/2019/08/15/1565858935676.html
---
SQL语句的种类
 
 一 、**DDL 数据定义语言  (Date Definition Language)**：定义了不同的数据段、数据库、表、列、索引等数据库对象的定义。
 创建数据库
 
```
 CREATE DATABASE dbname;
```

 
删除数据库
 
```
 DROP DATABASE dbname;
```

 
创建表
 
```
 CREATE TABLE tablename(
 column_name1  column_type1 constraints,
 column_name2 column_type2 constraints
 ......
 )
```

 
删除表
 
```
 DROP TABLE tablename
```

 
修改表 (importance)
 
  (1) 修改表类型
 
```
 ALTER TABLE tablename MODIFY [COLUMN] column_name column_definition;
```

 
 (2) 增加表字段
 
```
 ALTER TABLE  tablename ADD [COLUMN]column_name column_definition;
```

 
 (3) 删除表字段
 
```
 ALTER TABLE tablename DROP [COLUMN] column_name;
```

 
 (4) 字段改名
 
```
 ALTER TABLE tablename CHANGE [COLUMN] old_col_name new _col_name column_definition;
```

 
 (5) 表改名
 
```
 ALTER TABLE tablename RENAME [TO] new_tablename;
```

 
 二、 **DML 数据操作语言(Data Manipulation Language)**：用于添加、更新、删除和查询数据库记录，并检查数据完整性。
 
 插入记录
 
```
 INSERT INTO tablenname(field1,field2,...fieldn) VALUES(value1,value2,...valuen);
```

 
 更新记录
 
```
 UPDATE tablename SET field1=value1,field2=value2........fieldn=valuen [WHERE CONDITION];
```

 
 删除记录
 
```
 DELETE FROM tablename [WHERE CONDITION];
```

 
 查询记录(importance)
 
```
 SELECT * FROM tablename [WHERE CONDITION];
```

 
 (1) 查询不重复的记录
 
```
 SELECT DISTINCT * FROM tablename;
```

 
 (2) 条件查询
 
```
 SELECT * FROM tablename WHERE CONDITION;
```

 
 (3)排序和限制
 
```
 SELECT * FROM tablename WHERE CONDITION  ORDER BY field DESC|ASC LIMIT num，num；
```

>  DESC：降序           ASC：升序  （默认ASC）       LIMIT：限制条数
 
 (4) 聚合
 
```
 SELECT [field1,field2,......fieldn] function_name FROM tablename
 [WHERE CONDITION] GROUP BY field WITH ROLLUP HAVING where_condition
```

 
>  聚合函数：SUM()、COUNT()、MAX()、MIN()
 
 GROUP BY 关键字表示要进行分类聚合的字段
 WITH ROLLUP 是可选语法，表明是否对分类聚合后的结果进行再汇总。
 HAVING 关键字表示对分类后的结果再进行条件的过滤。

` 注意：having 和 where 的区别在于 having 是对聚合后的结果进行条件的过滤，而 where 是在聚合前就对记录进行过滤，如果逻辑允许，我们尽可能用 where 先过滤记录，这样因为结果集减小，将对聚合的效率大大提高，最后再根据逻辑看是否用 having 进行再过滤。
 `
 (5) 表连接
 
 1、内连接（INNER JOIN）
 
 MySQL INNER JOIN子句将一个表中的行与其他表中的行进行匹配，并允许从两个表中查询包含列的行记录。
 
 INNER JOIN子句是SELECT语句的可选部分，它出现在FROM子句之后。
 
```
 SELECT column_list FROM t1 INNER JOIN t2 ON join_condition1
  INNER JOIN t3 ON join_condition2 ...WHERE where_conditions;
```

 
 2、左外连接
 
 是指以左边的表的数据为基准，去匹配右边的表的数据，如果匹配到就显示，匹配不到就显示为null。
 
```
 SELECT column_list FROM t1 LEFT JOIN t2 ON join_condition1 
 INNER JOIN t3 ON join_condition2 ...WHERE where_conditions;
```

 
 3、右外连接
 
 是指以右边的表的数据为基准，去匹配左边的表的数据，如果匹配到就显示，匹配不到就显示为null。
 
```
 SELECT column_list FROM t1 RIGHT JOIN t2 ON join_condition1 
 INNER JOIN t3 ON join_condition2 ...WHERE where_conditions;
```
 

 (6) 子查询
 
 某些情况下，当我们查询的时候，需要的条件是另外一个 select 语句的结果，这个时候，就要用到子查询。用于子查询的关键字主要包括 in、not in、=、!=、exists、not exists 等。
 
 三、 **DCL 数据控制语言 (Data Control Language)**：用于控制不同数据段直接的许可和访问级别的语句。这些语句定义了数据库、表、字段、用户的访问权限和安全级别。
 
 DCL 语句主要是 DBA 用来管理系统中的对象权限时所使用，一般的开发人员很少使用。
 
 创建用户
 
```
 CREATE USER username@IP IDENTIFIED BY 'PASSWORD';#(用户只能在指定IP地址登陆)
 CREATE USER username@'%' IDENTIFIED BY 'PASSWORD';#（用户可以在任意IP地址登陆）
```

 
给用户授权
 
```
 GRANT 权限1，权限2，........ON database_name.* to username@IP;#（给用户分派在指定的数据库的指定的权限）
 GRANT ALL ON DATABASE_NAME.* TO 用户名@ ；#（给用户分派在指定数据库的所有的权限）
```

 
 撤销授权
 
```
 REVOKE 权限1，........权限n ON database_name.* FROM username@IP;(撤销指定用户在指定数据上的指定权限)
```

 
 查看权限
 
```
 SHOW GRANTS FOR username@IP ;(查看指定用户的权限)
```

 
 删除用户
 
```
 DROP USER username@IP (删除用户)
```

 
 修改用户密码
 
```
 USE mysql;
 UPDATE USER SET PASSWORD=PASSWORD('password') WHERE User='Username';
 FLUSH PRIVILEGES;
```


